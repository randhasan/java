public interface Workable
{
    public String work();
}
